# devops project for microservices application

![DevOps Architecture](https://user-images.githubusercontent.com/104420122/209148669-80b4390d-5cfa-4291-b651-11af38042100.png)

<img width="673" alt="Capture d’écran 2022-12-29 102543" src="https://user-images.githubusercontent.com/70517765/209931388-1acac867-d95d-43e9-8ebe-65bd5e585633.png">
